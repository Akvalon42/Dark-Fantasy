<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="MonedaR" tilewidth="80" tileheight="16" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../Coin_Gems/MonedaR.png" width="80" height="16"/>
 </tile>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="болото" tilewidth="32" tileheight="32" tilecount="60" columns="10">
 <image source="free-swamp-game-tileset-pixel-art (1)/1 Tiles/Tileset.png" width="320" height="192"/>
</tileset>
